INSERT INTO PRODUCT VALUES(10001,'levis-shirts',8090,999L,'levis-shirts')
INSERT INTO PRODUCT VALUES(10002,'levis-jeans',8090,999L,'levis-jeans')
INSERT INTO PRODUCT VALUES(10003,'levis-tshirt',8090,999L,'levis-tshirt')