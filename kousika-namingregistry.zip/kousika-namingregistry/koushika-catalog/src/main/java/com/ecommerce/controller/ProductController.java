package com.ecommerce.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.ecommerce.entity.Product;
import com.ecommerce.repository.PriceProxy;

@RestController
public class ProductController {

	@Autowired
	private PriceProxy priceProxy;

	@GetMapping("productRest/{id}")
	public Product getProduct(@PathVariable String id) {
		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("productId", id);
		ResponseEntity<Product> product = new RestTemplate()
				.getForEntity("http://localhost:8080/product/{productId}/price", Product.class, uriVariables);
		return product.getBody();
	}

	@GetMapping("productFeign/{id}")
	public Product getProductFeign(@PathVariable String id) {
		return priceProxy.getPrice(id);
	}

}
