package com.ecommerce.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.entity.Price;
import com.ecommerce.repository.PriceRepository;

@RestController
public class PriceController {

	@Autowired
	private Environment environment;

	@Autowired
	private PriceRepository priceRepository;

	@GetMapping("/product/{productId}/price")
	public Price getPrice(@PathVariable String productId) {
		Optional<Price> price = priceRepository.findByProductId(productId);
		Price priceFromDB = null;
		if (price.isPresent()) {
			priceFromDB = price.get();
			priceFromDB.setPort(Integer.valueOf(environment.getProperty("local.server.port")));
		} else {
			priceFromDB = new Price(1003L, productId, 0, Integer.valueOf(environment.getProperty("local.server.port")));
		}
		return priceFromDB;
	}
}
