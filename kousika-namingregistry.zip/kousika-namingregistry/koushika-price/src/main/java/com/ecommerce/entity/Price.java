package com.ecommerce.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Price {

	@Id
	@GeneratedValue
	private long id;

	private String productId;

	private float price;

	private int port;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public Price(long id, String productId, float price, int port) {
		super();
		this.id = id;
		this.productId = productId;
		this.price = price;
		this.port = port;
	}

	public Price() {
		super();
		// TODO Auto-generated constructor stub
	}

}
