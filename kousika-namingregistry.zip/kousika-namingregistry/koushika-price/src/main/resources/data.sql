INSERT into PRICE values (1001L,8080,999,'levis_shirts')
INSERT into PRICE values (1002L,8080,998,'levis_tShirt')
INSERT into PRICE values (1003L,8080,97,'kerchief')